/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "E:/Works/ISE/Test_Full_Adder_1Bit/AND_TEST_BENCH.vhd";



static void work_a_3944427857_3671711236_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    int64 t7;
    unsigned char t8;
    unsigned char t9;
    int t10;
    int t11;

LAB0:    t1 = (t0 + 2632U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(45, ng0);
    t2 = (t0 + 3016);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(46, ng0);
    t2 = (t0 + 3080);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(47, ng0);
    t7 = (15 * 1000LL);
    t2 = (t0 + 2440);
    xsi_process_wait(t2, t7);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(48, ng0);
    t2 = (t0 + 1352U);
    t3 = *((char **)t2);
    t8 = *((unsigned char *)t3);
    t9 = (t8 == (unsigned char)2);
    if (t9 == 0)
        goto LAB8;

LAB9:    xsi_set_current_line(49, ng0);
    t2 = (t0 + 1352U);
    t3 = *((char **)t2);
    t8 = *((unsigned char *)t3);
    t9 = (t8 != (unsigned char)2);
    if (t9 != 0)
        goto LAB10;

LAB12:
LAB11:    xsi_set_current_line(54, ng0);
    t2 = (t0 + 3016);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(55, ng0);
    t2 = (t0 + 3080);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(56, ng0);
    t7 = (15 * 1000LL);
    t2 = (t0 + 2440);
    xsi_process_wait(t2, t7);

LAB15:    *((char **)t1) = &&LAB16;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB8:    t2 = (t0 + 4928);
    xsi_report(t2, 7U, (unsigned char)2);
    goto LAB9;

LAB10:    xsi_set_current_line(50, ng0);
    t2 = (t0 + 1648U);
    t4 = *((char **)t2);
    t10 = *((int *)t4);
    t11 = (t10 + 1);
    t2 = (t0 + 1648U);
    t5 = *((char **)t2);
    t2 = (t5 + 0);
    *((int *)t2) = t11;
    goto LAB11;

LAB13:    xsi_set_current_line(57, ng0);
    t2 = (t0 + 1352U);
    t3 = *((char **)t2);
    t8 = *((unsigned char *)t3);
    t9 = (t8 == (unsigned char)2);
    if (t9 == 0)
        goto LAB17;

LAB18:    xsi_set_current_line(58, ng0);
    t2 = (t0 + 1352U);
    t3 = *((char **)t2);
    t8 = *((unsigned char *)t3);
    t9 = (t8 != (unsigned char)2);
    if (t9 != 0)
        goto LAB19;

LAB21:
LAB20:    xsi_set_current_line(63, ng0);
    t2 = (t0 + 3016);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(64, ng0);
    t2 = (t0 + 3080);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(65, ng0);
    t7 = (15 * 1000LL);
    t2 = (t0 + 2440);
    xsi_process_wait(t2, t7);

LAB24:    *((char **)t1) = &&LAB25;
    goto LAB1;

LAB14:    goto LAB13;

LAB16:    goto LAB14;

LAB17:    t2 = (t0 + 4935);
    xsi_report(t2, 7U, (unsigned char)2);
    goto LAB18;

LAB19:    xsi_set_current_line(59, ng0);
    t2 = (t0 + 1648U);
    t4 = *((char **)t2);
    t10 = *((int *)t4);
    t11 = (t10 + 1);
    t2 = (t0 + 1648U);
    t5 = *((char **)t2);
    t2 = (t5 + 0);
    *((int *)t2) = t11;
    goto LAB20;

LAB22:    xsi_set_current_line(66, ng0);
    t2 = (t0 + 1352U);
    t3 = *((char **)t2);
    t8 = *((unsigned char *)t3);
    t9 = (t8 == (unsigned char)3);
    if (t9 == 0)
        goto LAB26;

LAB27:    xsi_set_current_line(67, ng0);
    t2 = (t0 + 1352U);
    t3 = *((char **)t2);
    t8 = *((unsigned char *)t3);
    t9 = (t8 != (unsigned char)3);
    if (t9 != 0)
        goto LAB28;

LAB30:
LAB29:    xsi_set_current_line(72, ng0);
    t2 = (t0 + 1648U);
    t3 = *((char **)t2);
    t10 = *((int *)t3);
    t8 = (t10 == 0);
    if (t8 != 0)
        goto LAB31;

LAB33:    xsi_set_current_line(75, ng0);
    if ((unsigned char)1 == 0)
        goto LAB36;

LAB37:
LAB32:    goto LAB2;

LAB23:    goto LAB22;

LAB25:    goto LAB23;

LAB26:    t2 = (t0 + 4942);
    xsi_report(t2, 7U, (unsigned char)2);
    goto LAB27;

LAB28:    xsi_set_current_line(68, ng0);
    t2 = (t0 + 1648U);
    t4 = *((char **)t2);
    t10 = *((int *)t4);
    t11 = (t10 + 1);
    t2 = (t0 + 1648U);
    t5 = *((char **)t2);
    t2 = (t5 + 0);
    *((int *)t2) = t11;
    goto LAB29;

LAB31:    xsi_set_current_line(73, ng0);
    if ((unsigned char)0 == 0)
        goto LAB34;

LAB35:    goto LAB32;

LAB34:    t2 = (t0 + 4949);
    xsi_report(t2, 5U, (unsigned char)0);
    goto LAB35;

LAB36:    t2 = (t0 + 4954);
    xsi_report(t2, 6U, (unsigned char)2);
    goto LAB37;

}


extern void work_a_3944427857_3671711236_init()
{
	static char *pe[] = {(void *)work_a_3944427857_3671711236_p_0};
	xsi_register_didat("work_a_3944427857_3671711236", "isim/andGate_tb_isim_beh.exe.sim/work/a_3944427857_3671711236.didat");
	xsi_register_executes(pe);
}
